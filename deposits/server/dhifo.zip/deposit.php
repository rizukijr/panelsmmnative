<?php
require("../mainconfig.php");
require("function_bca.php");
$methode = "Bank BCA";

$get = mysqli_query($db, "SELECT * FROM deposits WHERE status = 'Pending' AND method = '$methode'");
if(mysqli_num_rows($get) == 0) {
	die("No data available");
} else {
    while($data_deposito = mysqli_fetch_assoc($get)) {
        $invoice = $data_deposito['code'];
        $user = $data_deposito['user'];
        $jumlah = $data_deposito['quantity'];
        $balance = $data_deposito['balance'];
        
        $check = check_bca($jumlah);
        
        if($check == "sukses") {
            $update = mysqli_query($db, "UPDATE deposits set status = 'Success' WHERE code = '$invoice'");
            $update = mysqli_query($db, "UPDATE users set balance = balance+$balance WHERE username = '$user'");
            if($update) {
              echo "Faktur Pembayaran untuk $invoice => Telah berhasil di update menjadi Sukses <br />";
            } else {
                echo "Gagal Update!!! <br />";
            }
        } else {
           echo "Faktur Pembayaran untuk $invoice => Dana tidak diterima <br />";
      }
   }
}


