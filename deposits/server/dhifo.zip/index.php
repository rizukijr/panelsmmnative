<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
    $sess_username = $_SESSION['user']['username'];
    $check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
    $data_user = mysqli_fetch_assoc($check_user);
    if (mysqli_num_rows($check_user) == 0) {
        header("Location: ".$cfg_baseurl."account/logout");
    } else if ($data_user['status'] == "Suspended") {
        header("Location: ".$cfg_baseurl."account/logout");
    }

    include("../lib/header.php");
    $msg_type = "nothing";

    if (isset($_POST['submit'])) {
        $post_method = $_POST['method'];
        $post_quantity = $_POST['quantity'];
        $post_sender = $_POST['sender'];


        $check_depo = mysqli_query($db, "SELECT * FROM deposits WHERE user = '$sess_username' AND status = 'Pending'");

        $check_service = mysqli_query($db, "SELECT * FROM deposit_method WHERE id = '$post_method'");
        $data_service = mysqli_fetch_assoc($check_service);

        $rate = $data_service['rate'];
        $balance = $rate*$post_quantity;
        $code = random_number(15);
        $note = $data_service['note'];
        $method = $data_service['name'];
        $match = preg_match("/Bank/", $method);
        if($match == true) {
            $random_angka = rand(1,999);
            $post_quantity = $post_quantity+$random_angka;
            $balance = $post_quantity;
        }
        $min_depo = "10000"; // edit min depo
        

        if (empty($post_method) || empty($post_quantity)) {
            $msg_type = "error";
            $msg_content = "×</span></button><b>Gagal:</b> Mohon mengisi input.";
        } else if (mysqli_num_rows($check_depo) > 3) {
            $msg_type = "error";
            $msg_content = "×</span></button><b>Gagal:</b> Terdeteksi spam, Anda memiliki lebih dari 3 deposito Pending, segera lunasi.";
        } else if (mysqli_num_rows($check_service) == 0) {
            $msg_type = "error";
            $msg_content = "×</span></button><b>Gagal:</b> Metode tidak ditemukan.";
        } else if ($post_quantity < $min_depo) {
            $msg_type = "error";
            $msg_content = "×</span></button><b>Gagal:</b> Jumlah minimal adalah ".$min_depo.".";
        } else {
            $insert_depo = mysqli_query($db, "INSERT INTO deposits (code, user, method, note, sender, quantity, balance, status, date) VALUES ('$code', '$sess_username', '$method', '$note', '$post_sender', '$post_quantity', '$balance', 'Pending', '$date')");
            if ($insert_depo == TRUE) {
                $msg_type = "success";
                $msg_content = "×</span></button><b>Permintaan telah dikirim.</b><br /><b>Metode:</b> $method<br /><b>Kode Faktur:</b> ".$code."<br /><hr />Silahkan kirim pembayaran ke <b>".$note."</b> sebesar <b>Rp ".number_format($post_quantity,0,',','.')."</b> ( Jumlah Wajib Sama jika ada kode unik dan dikonfirmasi oleh sistem secara Otomatis Jika ada Kode Uniknya), Jika tidak ada kode unik harap konfirmasi secara manual ke <b>Admin</b>";
            } else {
                $msg_type = "error";
                $msg_content = "×</span></button><b>Gagal:</b> Error system (2).";
            }
        }
    }
    
    $check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
    $data_user = mysqli_fetch_assoc($check_user);
?>

            <div class="row">
                <div class="col-md-7">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                           <h5><i class="fa fa-bank"></i> Deposit Saldo</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    </div>
                                </div>
                                    <div class="ibox-content">
                                        <?php 
                                        if ($msg_type == "success") {
                                        ?>
                                        <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><?php echo $msg_content; ?></div>
                                        <?php
                                        } else if ($msg_type == "error") {
                                        ?>
                                        <div class="alert alert-danger alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><?php echo $msg_content; ?></div>
                                        <?php
                                        }
                                        ?>
                                        <form class="form-horizontal" role="form" method="POST">
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Metode</label>
                                                <div class="col-md-10">
                                                    <select class="form-control" name="method" id="depomethod">
                                                        <option value="0">-- Pilih Metode --</option>
                                                        <?php
                                                        $check_cat = mysqli_query($db, "SELECT * FROM deposit_method ORDER BY name ASC");
                                                        while ($data_cat = mysqli_fetch_assoc($check_cat)) {
                                                        ?>
                                                        <option value="<?php echo $data_cat['id']; ?>"><?php echo $data_cat['name']; ?></option>
                                                        <?php
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <input type="hidden" id="rate" value="0">
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Pengirim</label>
                                                <div class="col-md-10">
                                                    <input type="text" name="sender" class="form-control" placeholder="Masukan Nomor hp / Rekening Pengirim">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Jumlah Deposit</label>
                                                <div class="col-md-10">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Rp</span>
                                                    <input type="number" name="quantity" class="form-control" placeholder="Jumlah" onkeyup="get_total(this.value).value;">
                                                    </div>
                                                </div>
                                            </div>  
                                            <input type="hidden" id="rate" value="0">
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Saldo Didapat</label>
                                                <div class="col-md-10">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Rp</span>
                                                    <input type="number" class="form-control" id="total" readonly>
                                                </div>
                                            </div>
                                        </div>                                      
                                            <div class="form-group">
                                            <div class="col-md-offset-2 col-md-10">
                                                <button type="submit" class="btn btn-primary" name="submit"><i class="fa fa-send"></i> Submit</button>
                                                <button type="reset" class="btn btn-warning" name="submit"><i class="fa fa-refresh"></i> Reset</button>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                <div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                           <h5><i class="fa fa-warning"></i> Perhatian</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    </div>
                                </div>
                                    <div class="ibox-content">
                                        <p><b>Petunjuk deposit:</b></p>
                                        <ul>
                                            <li>Deposito Manual diverifikasi secara manual oleh Admin.</li>
                                            <li>Deposito Manual diverifikasi secara automatis oleh sistem.</li>
                                            <li>Anda diwajibkan mengirikan bukti pembayaran berupa ID Deposito dan Bukti Transfer ke kontak Admin yang tersedia dibawah setelah melakukan pembayaran.</li>
                                            <li>Silahkan konfirmasi melalui ticket jika sudah melakukan pembayaran.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>                          
                        </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                           <h5><i class="fa fa-history"></i> Riwayat Deposit</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    </div>
                                </div>
                                    <div class="ibox-content">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-condense">
                                                <thead>
                                                    <tr>
                                                        <th>Tanggal</th>
                                                        <th>Faktur</th>
                                                        <th>Pengirim</th>
                                                        <th>Metode</th>
                                                        <th>Jumlah Transfer</th>
                                                        <th>Saldo didapat</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $check_deposit = mysqli_query($db, "SELECT * FROM deposits WHERE user = '$sess_username' ORDER BY id DESC");
                                                    $no = 1;
                                                    while ($data_deposit = mysqli_fetch_assoc($check_deposit)) {
                                                    if($data_deposit['status'] == "Pending") {
                                                        $label = "warning";
                                                    } else if($data_deposit['status'] == "Error") {
                                                        $label = "danger";
                                                    } else if($data_deposit['status'] == "Success") {
                                                        $label = "success";
                                                    }                                                       

                                                    ?>                                                  
                                                    <tr>
                                                        <td><?php echo $data_deposit['date']; ?></td>
                                                        <td><?php echo $data_deposit['code']; ?></td>
                                                        <td><?php echo $data_deposit['sender']; ?></td>
                                                        <td><?php echo $data_deposit['method']; ?> ( <?php echo $data_deposit['note']; ?> )</td>
                                                        <td><?php echo $data_deposit['quantity']; ?></td>
                                                        <td><?php echo $data_deposit['balance']; ?></td>
                                                        <td><label class="label label-<?php echo $label; ?>"><?php echo $data_deposit['status']; ?></label></td>
                                                    </tr>
                                                    <?php
                                                    }
                                                    ?>
                                                    </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>                          
                        </div>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#depomethod").change(function() {
                var method = $("#depomethod").val();
                $.ajax({
                    url: '<?php echo $cfg_baseurl; ?>inc/depo_rate.php',
                    data: 'method=' + method,
                    type: 'POST',
                    dataType: 'html',
                    success: function(msg) {
                        $("#rate").val(msg);
                    }
                });
            });
            $("#category").change(function() {
                var category = $("#category").val();
                $.ajax({
                    url: '<?php echo $cfg_baseurl; ?>inc/order_service.php',
                    data: 'category=' + category,
                    type: 'POST',
                    dataType: 'html',
                    success: function(msg) {
                        $("#service").html(msg);
                    }
                });
            });
            $("#service").change(function() {
                var service = $("#service").val();
                $.ajax({
                    url: '<?php echo $cfg_baseurl; ?>inc/order_note.php',
                    data: 'service=' + service,
                    type: 'POST',
                    dataType: 'html',
                    success: function(msg) {
                        $("#note").html(msg);
                    }
                });
                $.ajax({
                    url: '<?php echo $cfg_baseurl; ?>inc/order_rate.php',
                    data: 'service=' + service,
                    type: 'POST',
                    dataType: 'html',
                    success: function(msg) {
                        $("#rate").val(msg);
                    }
                });
            });
        });

        function get_total(quantity) {
            var rate = $("#rate").val();
            var result = eval(quantity) * rate;
            $('#total').val(result);
        }
    </script>                                           
<?php
    include("../lib/footer.php");
} else {
    header("Location: ".$cfg_baseurl);
}
?>